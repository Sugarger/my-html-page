# 职途规划社 - 技能树职业规划系统

一个纯静态单页应用，无需后端，开箱即用。

## 快速部署

### 方式一：Vercel（推荐，1分钟上线）

1. 注册/登录 [vercel.com](https://vercel.com)
2. 点击 **Add New Project** → **Import Git Repository**
3. 将本目录上传至 GitHub 仓库，再导入
4. 或直接拖拽本文件夹到 Vercel 部署页面

### 方式二：GitHub Pages

1. 新建 GitHub 仓库
2. 将本目录所有文件上传到仓库根目录
3. 进入仓库 Settings → Pages → 选择 main 分支 → Save
4. 访问 `https://<用户名>.github.io/<仓库名>`

### 方式三：Nginx 自托管（CentOS 服务器）

```bash
# 将 index.html 上传到服务器
scp index.html root@你的服务器IP:/usr/share/nginx/html/

# 服务器上重启 Nginx
nginx -s reload
```

### 方式四：本地直接打开

直接用浏览器打开 `index.html` 文件即可使用，无需服务器。

## 文件说明

| 文件 | 说明 |
|------|------|
| `index.html` | 网站全部内容（CSS + JS + HTML 一体） |
| `vercel.json` | Vercel 平台部署配置 |
| `README.md` | 本说明文档 |

## 功能模块

- 🗺️ 技能树 - 可视化职业技能图谱
- 🏢 职业赛道 - 多赛道职业路线规划
- 💰 薪资模拟器 - 薪资预测与增长模拟
- 💻 项目实战 - 分级项目练手指南
- 📚 最佳实践 - 面试/编码/职业/工具技巧
- 🎯 成就系统 - 技能学习进度追踪
